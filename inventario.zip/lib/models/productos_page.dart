import 'package:flutter/material.dart';
import 'producto.dart';

class ProductosPage extends StatelessWidget {
  final List<Producto> productos;

  const ProductosPage({
    super.key,
    required this.productos,
  });

  String fecha(DateTime fecha) {
    return '${fecha.day}/${fecha.month}/${fecha.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Productos registrados'),
      ),
      body: productos.isEmpty
          ? const Center(
              child: Text('No hay productos registrados'),
            )
          : SizedBox(
              width: double.infinity,
              child: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    columns: const [
                      DataColumn(label: Text('Código')),
                      DataColumn(label: Text('Nombre')),
                      DataColumn(label: Text('Categoría')),
                      DataColumn(label: Text('Precio')),
                      DataColumn(label: Text('Stock')),
                      DataColumn(label: Text('Estado')),
                    ],
                    rows: productos.map((producto) {
                      return DataRow(
                        cells: [
                          DataCell(Text(producto.codigo)),
                          DataCell(Text(producto.nombre)),
                          DataCell(Text(producto.categoria)),
                          DataCell(
                            Text('S/ ${producto.precio.toStringAsFixed(2)}'),
                          ),
                          DataCell(Text(producto.stock.toString())),
                          DataCell(Text(producto.estado)),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
    );
  }
}