import 'package:flutter/material.dart';
import 'models/producto.dart';
import 'models/productos_page.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'InventarioApp',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue,
        ),
        useMaterial3: true,
      ),
      home: const RegistroProducto(),
    );
  }
}

class RegistroProducto extends StatefulWidget {
  const RegistroProducto({super.key});

  @override
  State<RegistroProducto> createState() => _RegistroProductoState();
}

class _RegistroProductoState extends State<RegistroProducto> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _codigoController =
      TextEditingController();

  final TextEditingController _nombreController =
      TextEditingController();

  final TextEditingController _precioController =
      TextEditingController();

  final List<Producto> _productos = <Producto>[];

  String? _categoria;
  String _estado = 'Disponible';
  double _stock = 0;
  DateTime? _fechaIngreso;
  bool _perecible = false;

  final List<String> _categorias = [
    'Abarrotes',
    'Bebidas',
    'Limpieza',
    'Golosinas',
    'Lácteos',
    'Otro',
  ];

  @override
  void dispose() {
    _codigoController.dispose();
    _nombreController.dispose();
    _precioController.dispose();
    super.dispose();
  }

  Future<void> _seleccionarFecha() async {
    final DateTime? fecha = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );

    if (fecha != null) {
      setState(() {
        _fechaIngreso = fecha;
      });
    }
  }

  void _registrarProducto() {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    if (_categoria == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Seleccione una categoría'),
        ),
      );
      return;
    }

    if (_fechaIngreso == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Seleccione la fecha de ingreso'),
        ),
      );
      return;
    }

    final Producto producto = Producto(
      codigo: _codigoController.text,
      nombre: _nombreController.text,
      categoria: _categoria!,
      precio: double.parse(_precioController.text),
      stock: _stock.toInt(),
      estado: _estado,
      fechaIngreso: _fechaIngreso!,
      perecible: _perecible,
    );

    setState(() {
      _productos.add(producto);

      _codigoController.clear();
      _nombreController.clear();
      _precioController.clear();

      _categoria = null;
      _estado = 'Disponible';
      _stock = 0;
      _fechaIngreso = null;
      _perecible = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Producto registrado correctamente'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('InventarioApp'),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 15),
            child: Center(
              child: Badge(
                label: Text(_productos.length.toString()),
                child: const Icon(Icons.inventory),
              ),
            ),
          ),
        ],
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              const Text(
                'REGISTRO DE PRODUCTO',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 20),

              TextFormField(
                controller: _codigoController,
                keyboardType: TextInputType.number,
                maxLength: 6,
                decoration: const InputDecoration(
                  labelText: 'Código del producto',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Ingrese el código';
                  }

                  if (!RegExp(r'^[0-9]{6}$').hasMatch(value)) {
                    return 'Debe tener exactamente 6 dígitos';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 15),

              TextFormField(
                controller: _nombreController,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(
                  labelText: 'Nombre del producto',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Ingrese el nombre';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 15),

              DropdownButtonFormField<String>(
                value: _categoria,
                decoration: const InputDecoration(
                  labelText: 'Categoría',
                  border: OutlineInputBorder(),
                ),
                items: _categorias.map((String categoria) {
                  return DropdownMenuItem<String>(
                    value: categoria,
                    child: Text(categoria),
                  );
                }).toList(),
                onChanged: (String? value) {
                  setState(() {
                    _categoria = value;
                  });
                },
              ),

              const SizedBox(height: 15),

              TextFormField(
                controller: _precioController,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: const InputDecoration(
                  labelText: 'Precio unitario (S/)',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Ingrese el precio';
                  }

                  final double? precio = double.tryParse(value);

                  if (precio == null || precio <= 0) {
                    return 'Ingrese un precio mayor que 0';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 20),

              Text(
                'Cantidad en stock: ${_stock.toInt()}',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),

              Slider(
                value: _stock,
                min: 0,
                max: 100,
                divisions: 100,
                label: _stock.toInt().toString(),
                onChanged: (double value) {
                  setState(() {
                    _stock = value;
                  });
                },
              ),

              const SizedBox(height: 10),

              const Text(
                'Estado del producto',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 10),

              SegmentedButton<String>(
                segments: const [
                  ButtonSegment<String>(
                    value: 'Disponible',
                    label: Text('Disponible'),
                  ),
                  ButtonSegment<String>(
                    value: 'Agotado',
                    label: Text('Agotado'),
                  ),
                ],
                selected: {_estado},
                onSelectionChanged: (Set<String> value) {
                  setState(() {
                    _estado = value.first;
                  });
                },
              ),

              const SizedBox(height: 20),

              ListTile(
                title: const Text('Fecha de ingreso'),
                subtitle: Text(
                  _fechaIngreso == null
                      ? 'No seleccionada'
                      : '${_fechaIngreso!.day}/${_fechaIngreso!.month}/${_fechaIngreso!.year}',
                ),
                trailing: ElevatedButton(
                  onPressed: _seleccionarFecha,
                  child: const Text('Seleccionar'),
                ),
              ),

              const SizedBox(height: 10),

              SwitchListTile(
                title: const Text('¿Producto perecible?'),
                value: _perecible,
                onChanged: (bool value) {
                  setState(() {
                    _perecible = value;
                  });
                },
              ),

              const SizedBox(height: 20),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _registrarProducto,
                  icon: const Icon(Icons.save),
                  label: const Text('Registrar producto'),
                ),
              ),

              const SizedBox(height: 15),

              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ProductosPage(
                          productos: _productos,
                        ),
                      ),
                    );
                  },
                  icon: const Icon(Icons.table_chart),
                  label: const Text('Ver productos registrados'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


   
